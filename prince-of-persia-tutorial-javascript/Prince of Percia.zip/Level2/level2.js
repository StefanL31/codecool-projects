/*
  Move the prince through the maze to find the princess.
  You can move the prince by calling the function `moveDirection`
  and passing the parameters
  `left`
  `right`
  `up`
  `down`
*/
moveDirection("up");
moveDirection("up");
moveDirection('right');
moveDirection('right');
moveDirection('down');
moveDirection('down');
moveDirection('right');
moveDirection('right');
moveDirection('down');
moveDirection('down');
moveDirection('down');
moveDirection('down');
moveDirection('left');
moveDirection('left');
moveDirection('up');
moveDirection('up');
moveDirection('left');
moveDirection('left');
moveDirection('down');