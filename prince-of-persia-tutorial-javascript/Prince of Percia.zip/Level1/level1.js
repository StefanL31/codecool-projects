/*
  Move the prince through the maze to find the princess.
  You can move the prince by calling the functions that
  are already created:
  `moveLeft`
  `moveUp`
  `moveDown`
  `moveRight`
*/

 moveUp();
 moveUp();
 moveRight();
 moveRight();
 moveRight();
 moveDown();
 moveDown();
 moveDown();
 moveDown();
 moveDown();
 moveLeft();
 moveLeft();
 moveLeft();
 moveUp();

 // A se vedea ca acest fisier a fost modificat.
