/*
  Move the prince through the maze to find the princess.
  You can move the prince by calling the already created
  function `moveDirection` and passing the STRING as PARAMETER
  `left`
  `right`
  `up`
  `down`.
  Extra challenge: use a `for` or a `while` statement to avoid
  writing multiple times the same function call.
*/

for (var i=0; i<8; i++) moveDirection('down');